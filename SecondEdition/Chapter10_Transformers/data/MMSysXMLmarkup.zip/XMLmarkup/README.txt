This is the XML extension of the Affect Corpus. 

It includes syntactic parses per story. All XML extensions are independent of the other annotations in this corpus. 
This set is provided as reference only. The sentence numbers for class and magnitude annotations in this corpus
do not align with the sentence number provided in the XML files. 
The XML mark-up should be used independently without class or magnitude annotations

To use the class and magnitude annotations, a user should use a lookup function to find 
the syntactic parse that matches a given sentence. Each syntactic parse can be converted into a raw sentence
by using NLTK's tree.leaves() function. With this, the user may match and find the parse. 
